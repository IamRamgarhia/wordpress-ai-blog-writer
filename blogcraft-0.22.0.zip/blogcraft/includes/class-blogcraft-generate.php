<?php
/**
 * Manual post generation screen.
 *
 * @package Blogcraft
 */

defined( 'ABSPATH' ) || exit;

/**
 * Lets a user queue a topic and watch it move through the pipeline.
 *
 * Generation is queued rather than run inline: a full pipeline is five provider
 * calls, which would exceed PHP's execution limit on most shared hosting if it
 * ran during the form submission.
 */
class Blogcraft_Generate {

	/**
	 * Submenu slug.
	 */
	const PAGE_SLUG = 'blogcraft-write';

	/**
	 * Nonce action for queueing a topic.
	 */
	const QUEUE_ACTION = 'blogcraft_queue_topic';

	/**
	 * Nonce action for running the queue on demand.
	 */
	const RUN_ACTION = 'blogcraft_run_queue_now';

	/**
	 * Nonce action for bulk topic import.
	 */
	const BULK_ACTION = 'blogcraft_bulk_topics';

	/**
	 * Nonce action for rolling a batch back.
	 */
	const ROLLBACK_ACTION = 'blogcraft_rollback';

	/**
	 * Transient prefix holding the last notice for one user.
	 */
	const NOTICE_TRANSIENT = 'blogcraft_write_notice_';

	/**
	 * Wire hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 15 );
		add_action( 'admin_post_blogcraft_queue_topic', array( __CLASS__, 'handle_queue' ) );
		add_action( 'admin_post_blogcraft_run_queue_now', array( __CLASS__, 'handle_run_now' ) );
		add_action( 'admin_post_blogcraft_bulk_topics', array( __CLASS__, 'handle_bulk' ) );
		add_action( 'admin_post_blogcraft_rollback', array( __CLASS__, 'handle_rollback' ) );
		add_action( 'wp_ajax_blogcraft_preview_post', array( __CLASS__, 'handle_preview' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	/**
	 * Load the composer's styling and behaviour, on this screen only.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE_SLUG ) ) {
			return;
		}

		wp_enqueue_style(
			'blogcraft-blueprint',
			BLOGCRAFT_URL . 'assets/blueprint.css',
			array(),
			BLOGCRAFT_VERSION
		);

		wp_enqueue_script(
			'blogcraft-compose',
			BLOGCRAFT_URL . 'assets/compose.js',
			array(),
			BLOGCRAFT_VERSION,
			true
		);

		wp_localize_script(
			'blogcraft-compose',
			'blogcraftCompose',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			)
		);
	}

	/**
	 * The outcome panel, reduced to markup that cannot carry script.
	 *
	 * Everything in outcome_html() is escaped as it is built, so this changes
	 * nothing today. It exists so that the front end can keep inserting the
	 * response as markup without that being one careless future edit away from
	 * an injection: the allowlist below has no script, no event attributes and
	 * no href, so there is nothing to exploit even if an unescaped value slips
	 * in upstream.
	 *
	 * @param array $blueprint Blueprint to describe.
	 * @return string
	 */
	private static function safe_outcome( $blueprint ) {
		return wp_kses(
			self::outcome_html( $blueprint ),
			array(
				'ol'   => array( 'class' => array() ),
				'li'   => array( 'class' => array() ),
				'div'  => array( 'class' => array() ),
				'p'    => array( 'class' => array() ),
				'span' => array( 'class' => array() ),
			)
		);
	}

	/**
	 * Recompute the outcome panel for an unsaved brief.
	 *
	 * Rendered server-side for the same reason the blueprint brief is: the panel
	 * claims to predict what will actually be produced, and a second copy of that
	 * arithmetic in script would drift from the one the pipeline uses.
	 *
	 * @return void
	 */
	public static function handle_preview() {
		if ( ! current_user_can( Blogcraft_Capabilities::MANAGE ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'blogcraft' ) ), 403 );
		}

		$nonce = isset( $_POST['_blogcraft_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_blogcraft_nonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! Blogcraft_Request::verify( self::QUEUE_ACTION, $nonce ) ) {
			wp_send_json_error( array( 'message' => __( 'That form has expired. Reload the page.', 'blogcraft' ) ), 403 );
		}

		$raw = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- every field is sanitised by type in Blogcraft_Blueprint::normalise().

		$blueprint = Blogcraft_Blueprint::with_overrides(
			Blogcraft_Blueprint::get(),
			self::overrides_from( $raw )
		);

		$topic = isset( $raw['topic'] ) && ! is_array( $raw['topic'] ) ? sanitize_text_field( (string) $raw['topic'] ) : '';
		$clash = Blogcraft_Preview::clash( $topic );

		wp_send_json_success(
			array(
				'outcome' => self::safe_outcome( $blueprint ),
				'clash'   => ( '' === $clash )
					? ''
					: sprintf(
						/* translators: %s: the clashing topic. */
						__( 'This looks like a repeat of "%s". Queueing it anyway is allowed, but near-identical posts are what search engines penalise.', 'blogcraft' ),
						$clash
					),
			)
		);
	}

	/**
	 * Add the submenu.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_submenu_page(
			Blogcraft_Admin::MENU_SLUG,
			__( 'Write a post', 'blogcraft' ),
			__( 'Write a post', 'blogcraft' ),
			Blogcraft_Capabilities::MANAGE,
			self::PAGE_SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( Blogcraft_Capabilities::MANAGE ) ) {
			wp_die( esc_html__( 'You are not allowed to access this page.', 'blogcraft' ) );
		}

		$notice = get_transient( self::NOTICE_TRANSIENT . get_current_user_id() );

		echo '<div class="wrap blogcraft-page blogcraft-compose-page">';
		Blogcraft_Nav::render();
		echo '<div class="blogcraft-head">';
		echo '<h1>' . esc_html__( 'Write a post', 'blogcraft' ) . '</h1>';
		echo '<p>' . esc_html__( 'Give it a topic. It researches, drafts, critiques its own work, rewrites, then checks the result before anything reaches your site.', 'blogcraft' ) . '</p>';
		echo '</div>';

		if ( is_array( $notice ) ) {
			delete_transient( self::NOTICE_TRANSIENT . get_current_user_id() );
			printf(
				'<div class="notice %s"><p>%s</p></div>',
				esc_attr( empty( $notice['ok'] ) ? 'notice-error' : 'notice-success' ),
				esc_html( (string) $notice['message'] )
			);
		}

		if ( ! Blogcraft_Provider_Registry::is_configured() ) {
			printf(
				'<div class="notice notice-warning"><p>%s</p></div>',
				esc_html__( 'No AI provider is configured yet. Set one up under Blogcraft → Settings first.', 'blogcraft' )
			);
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="blogcraft-compose">';
		echo '<input type="hidden" name="action" value="blogcraft_queue_topic" />';
		echo '<input type="hidden" name="bc_compose" value="1" />';
		Blogcraft_Request::nonce_field( self::QUEUE_ACTION );

		self::render_composer();

		echo '<div class="bc-compose-actions">';
		printf(
			'<button type="submit" class="bc-save">%s</button>',
			esc_html__( 'Queue this post', 'blogcraft' )
		);
		echo '</div>';
		echo '</form>';

		self::card_open( __( 'Queue', 'blogcraft' ), __( 'Posts are written in the background, one step per run.', 'blogcraft' ) );
		echo '<ul class="blogcraft-stats">';
		foreach ( array( 'pending', 'running', 'complete', 'failed' ) as $status ) {
			printf(
				'<li><span class="blogcraft-stat-value">%2$d</span><span class="blogcraft-stat-label">%1$s</span></li>',
				esc_html( $status ),
				(int) Blogcraft_Queue::count_by_status( $status )
			);
		}
		echo '</ul>';

		echo '<p class="description">' . esc_html__( 'A step runs on its own every few minutes. Run one by hand if you would rather not wait.', 'blogcraft' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="blogcraft_run_queue_now" />';
		Blogcraft_Request::nonce_field( self::RUN_ACTION );
		submit_button( __( 'Run the queue now', 'blogcraft' ), 'secondary' );
		echo '</form>';

		echo '</section>';
		self::card_open( __( 'Add many at once', 'blogcraft' ), __( 'One topic per line, or paste a CSV column.', 'blogcraft' ) );
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="blogcraft_bulk_topics" />';
		Blogcraft_Request::nonce_field( self::BULK_ACTION );
		printf(
			'<label for="blogcraft_topics" class="screen-reader-text">%s</label>',
			esc_html__( 'Topics, one per line', 'blogcraft' )
		);
		echo '<textarea class="large-text code" name="topics" id="blogcraft_topics" rows="6" placeholder="' . esc_attr__( 'One topic per line, or paste a CSV column', 'blogcraft' ) . '"></textarea>';
		echo '<p class="description">' . esc_html__( 'Repeats are skipped, whether the post already exists or is only queued. Duplicates within the list you paste are caught too.', 'blogcraft' ) . '</p>';
		submit_button( __( 'Queue all of these', 'blogcraft' ), 'secondary', 'submit', true );
		echo '</form>';

		echo '</section>';
		self::card_open( __( 'Undo a batch', 'blogcraft' ), __( 'Only touches posts Blogcraft created. Anything you wrote is left alone.', 'blogcraft' ) );
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(' . esc_attr( "'" . esc_js( __( 'Move recently generated posts to the trash?', 'blogcraft' ) ) . "'" ) . ');">';
		echo '<input type="hidden" name="action" value="blogcraft_rollback" />';
		Blogcraft_Request::nonce_field( self::ROLLBACK_ACTION );
		submit_button( __( 'Trash the last 24 hours', 'blogcraft' ), 'delete', 'submit', false );
		echo '</form>';
		echo '</div>';
	}

	/**
	 * Open a card section.
	 *
	 * @param string $title       Card title.
	 * @param string $description One line on what it is for.
	 * @return void
	 */
	private static function card_open( $title, $description ) {
		printf(
			'<section class="blogcraft-card"><header><h2>%1$s</h2><p>%2$s</p></header>',
			esc_html( $title ),
			esc_html( $description )
		);
	}

	/**
	 * Read blueprint overrides out of the submitted form.
	 *
	 * @param array $source Unslashed request data.
	 * @return array Sparse field values.
	 */
	/**
	 * The blueprint fields the composer lets a post override.
	 *
	 * Named explicitly rather than inferred from the request. Toggles post
	 * nothing when switched off, so without a known list there is no way to
	 * tell "the user turned the FAQ off" from "the field was never rendered",
	 * and one of those must not silently become the other.
	 *
	 * @return array Keys: text, toggle, multi.
	 */
	private static function override_fields() {
		return array(
			'text'   => array(
				'word_target',
				'sections_min',
				'sections_max',
				'intro_style',
				'conclusion_style',
				'tone',
				'tone_custom',
				'point_of_view',
				'audience',
				'audience_custom',
				'reading_level',
				'sentence_max_words',
				'primary_keyword',
				'secondary_keywords',
				'required_terms',
				'external_links_target',
				'banned_phrases',
				'negative_keywords',
				'avoid_subjects',
			),
			'toggle' => array(
				'takeaways',
				'faq',
				'toc',
				'tables',
				'lists',
				'sentence_variety',
				'allow_contractions',
				'allow_em_dash',
				'require_experience',
				'require_citations',
				'require_statistics',
			),
			'multi'  => array( 'literary_devices' ),
		);
	}

	/**
	 * Read this post's brief out of the submitted form.
	 *
	 * @param array $source Unslashed request data.
	 * @return array Sparse blueprint field values.
	 */
	private static function overrides_from( $source ) {
		$fields = self::override_fields();
		$out    = array();

		// Only treat this as an override submission when the composer was the
		// thing that posted, so the bulk form cannot blank the brief.
		if ( ! isset( $source['bc_compose'] ) ) {
			return $out;
		}

		foreach ( $fields['text'] as $key ) {
			$field = 'o_' . $key;

			if ( ! isset( $source[ $field ] ) || is_array( $source[ $field ] ) ) {
				continue;
			}

			$value = trim( (string) $source[ $field ] );

			if ( '' !== $value ) {
				$out[ $key ] = $value;
			}
		}

		// A toggle absent from the post means the user switched it off.
		foreach ( $fields['toggle'] as $key ) {
			$out[ $key ] = isset( $source[ 'o_' . $key ] );
		}

		foreach ( $fields['multi'] as $key ) {
			$field  = 'o_' . $key;
			$chosen = isset( $source[ $field ] ) && is_array( $source[ $field ] ) ? $source[ $field ] : array();
			$clean  = array();

			foreach ( $chosen as $value ) {
				$value = sanitize_key( (string) $value );

				if ( '' !== $value ) {
					$clean[] = $value;
				}
			}

			$out[ $key ] = implode( ',', $clean );
		}

		return $out;
	}

	/*
	 * Blogcraft_Controls escapes every value as it builds its markup, and
	 * outcome_html() does the same. PHPCS cannot follow a string across a method
	 * boundary, so it reads every echo below as raw output. Scoped off here
	 * rather than annotated a dozen times, which would bury the one place that
	 * genuinely needs reading.
	 */
	// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped

	/**
	 * The composer: topic, the full brief for this post, and what it will produce.
	 *
	 * This is where the work happens, so everything needed to decide "queue this
	 * or change something first" is on one screen. The panel on the right is the
	 * point: it shows the shape of the post, how the word budget divides, what
	 * the run will roughly cost, and whether the topic clashes with something
	 * already written — all before a token is spent.
	 *
	 * @return void
	 */
	private static function render_composer() {
		$blueprint = Blogcraft_Blueprint::get();

		echo '<div class="bc-compose">';
		echo '<div class="bc-compose-main">';

		self::render_topic();
		self::render_brief_tabs( $blueprint );

		echo '</div>';

		self::render_outcome( $blueprint );

		echo '</div>';
	}

	/**
	 * The topic field and the things that belong beside it.
	 *
	 * @return void
	 */
	private static function render_topic() {
		echo '<section class="bc-pane bc-pane-topic">';

		echo Blogcraft_Controls::row(
			__( 'Topic', 'blogcraft' ),
			__( 'A sentence works better than a keyword. Say what the post should actually answer.', 'blogcraft' ),
			'<input type="text" class="bc-text bc-text-lead" name="topic" id="bc_topic" value="" required autocomplete="off" placeholder="' . esc_attr__( 'How to choose a standing desk for a small home office', 'blogcraft' ) . '" /><p class="bc-clash" id="bc-clash" hidden></p>',
			'bc_topic'
		);

		echo Blogcraft_Controls::row(
			__( 'Angle for this post', 'blogcraft' ),
			__( 'Anything true of this one post only. This is what stops every post reading the same.', 'blogcraft' ),
			Blogcraft_Controls::area( 'instructions', '', __( 'Compare three price brackets and say which is worth it.', 'blogcraft' ), 2 ),
			'bc_instructions'
		);

		echo Blogcraft_Controls::row(
			__( 'What you know that nobody else does', 'blogcraft' ),
			__( 'Your own numbers, results, prices, or what happened when you tried it. This is the only part of a post a model cannot produce, and it is what separates a page worth reading from a summary of pages that already exist. Everything here is used as fact and never invented beyond.', 'blogcraft' ),
			Blogcraft_Controls::area(
				'evidence',
				'',
				__( 'We tested 9 desks over 4 months. The £220 bracket wobbled above 110cm; the £400 bracket did not. Our own returns rate on the cheapest was 3 in 9.', 'blogcraft' ),
				4
			),
			'bc_evidence'
		);

		echo Blogcraft_Controls::row(
			__( 'When it is finished', 'blogcraft' ),
			'',
			Blogcraft_Controls::segmented(
				'status',
				array(
					'draft'   => __( 'Save as a draft', 'blogcraft' ),
					'publish' => __( 'Publish it', 'blogcraft' ),
				),
				'draft'
			)
		);

		echo '</section>';
	}

	/**
	 * The full brief for this post, grouped behind tabs.
	 *
	 * Every field is prefixed so it overrides the saved blueprint for this post
	 * alone. Defaults are pre-filled from the blueprint rather than left blank,
	 * because a screen of empty fields hides what will actually happen.
	 *
	 * @param array $bp Resolved blueprint.
	 * @return void
	 */
	private static function render_brief_tabs( $bp ) {
		echo '<div class="bc-tabs" role="tablist">';

		$tabs = array(
			'shape' => __( 'Shape', 'blogcraft' ),
			'voice' => __( 'Voice', 'blogcraft' ),
			'seo'   => __( 'Search', 'blogcraft' ),
			'human' => __( 'Sounding human', 'blogcraft' ),
		);

		$first = true;

		foreach ( $tabs as $slug => $label ) {
			printf(
				'<button type="button" class="bc-tab%1$s" data-tab="%2$s" role="tab" aria-selected="%3$s">%4$s</button>',
				$first ? ' is-active' : '',
				esc_attr( $slug ),
				$first ? 'true' : 'false',
				esc_html( $label )
			);
			$first = false;
		}

		echo '</div>';

		self::tab_shape( $bp );
		self::tab_voice( $bp );
		self::tab_seo( $bp );
		self::tab_human( $bp );
	}

	/**
	 * Open one tab panel.
	 *
	 * @param string $slug   Tab slug.
	 * @param bool   $active Whether it starts visible.
	 * @return void
	 */
	private static function tab_open( $slug, $active = false ) {
		printf(
			'<section class="bc-pane bc-tabpanel%1$s" data-tab="%2$s" role="tabpanel"%3$s>',
			$active ? ' is-active' : '',
			esc_attr( $slug ),
			$active ? '' : ' hidden'
		);
	}

	/**
	 * Structure controls for this post.
	 *
	 * @param array $bp Blueprint.
	 * @return void
	 */
	private static function tab_shape( $bp ) {
		self::tab_open( 'shape', true );

		$rows = array(
			Blogcraft_Controls::row(
				__( 'Length', 'blogcraft' ),
				__( 'Measured on the finished draft.', 'blogcraft' ),
				Blogcraft_Controls::slider( 'o_word_target', 300, 4000, 50, $bp['word_target'], __( ' words', 'blogcraft' ) ),
				'bc_o_word_target'
			),
			Blogcraft_Controls::row(
				__( 'Fewest sections', 'blogcraft' ),
				'',
				Blogcraft_Controls::slider( 'o_sections_min', 1, 12, 1, $bp['sections_min'] ),
				'bc_o_sections_min'
			),
			Blogcraft_Controls::row(
				__( 'Most sections', 'blogcraft' ),
				'',
				Blogcraft_Controls::slider( 'o_sections_max', 1, 15, 1, $bp['sections_max'] ),
				'bc_o_sections_max'
			),
			Blogcraft_Controls::row(
				__( 'How it opens', 'blogcraft' ),
				'',
				Blogcraft_Controls::select( 'o_intro_style', Blogcraft_Blueprint::intro_styles(), $bp['intro_style'] ),
				'bc_o_intro_style'
			),
			Blogcraft_Controls::row(
				__( 'How it ends', 'blogcraft' ),
				'',
				Blogcraft_Controls::select( 'o_conclusion_style', Blogcraft_Blueprint::conclusion_styles(), $bp['conclusion_style'] ),
				'bc_o_conclusion_style'
			),
			Blogcraft_Controls::row(
				__( 'Include', 'blogcraft' ),
				'',
				Blogcraft_Controls::toggle( 'o_takeaways', $bp['takeaways'], __( 'Key takeaways', 'blogcraft' ) )
				. Blogcraft_Controls::toggle( 'o_faq', $bp['faq'], __( 'Questions and answers', 'blogcraft' ) )
				. Blogcraft_Controls::toggle( 'o_toc', $bp['toc'], __( 'Table of contents', 'blogcraft' ) )
				. Blogcraft_Controls::toggle( 'o_tables', $bp['tables'], __( 'Tables', 'blogcraft' ) )
				. Blogcraft_Controls::toggle( 'o_lists', $bp['lists'], __( 'Bulleted lists', 'blogcraft' ) )
			),
		);

		echo implode( '', $rows );
		echo '</section>';
	}

	/**
	 * Voice controls for this post.
	 *
	 * @param array $bp Blueprint.
	 * @return void
	 */
	private static function tab_voice( $bp ) {
		self::tab_open( 'voice' );

		$rows = array(
			Blogcraft_Controls::row(
				__( 'Tone', 'blogcraft' ),
				'',
				Blogcraft_Controls::select( 'o_tone', Blogcraft_Blueprint::tones(), $bp['tone'] ),
				'bc_o_tone'
			),
			Blogcraft_Controls::row(
				__( 'Describe the tone', 'blogcraft' ),
				__( 'Used only when the tone above is set to something else.', 'blogcraft' ),
				Blogcraft_Controls::text( 'o_tone_custom', $bp['tone_custom'], __( 'Dry, a little sceptical', 'blogcraft' ) ),
				'bc_o_tone_custom'
			),
			Blogcraft_Controls::row(
				__( 'Who is speaking', 'blogcraft' ),
				'',
				Blogcraft_Controls::segmented( 'o_point_of_view', Blogcraft_Blueprint::points_of_view(), $bp['point_of_view'] )
			),
			Blogcraft_Controls::row(
				__( 'Who is reading', 'blogcraft' ),
				'',
				Blogcraft_Controls::select( 'o_audience', Blogcraft_Blueprint::audiences(), $bp['audience'] ),
				'bc_o_audience'
			),
			Blogcraft_Controls::row(
				__( 'Describe the reader', 'blogcraft' ),
				'',
				Blogcraft_Controls::text( 'o_audience_custom', $bp['audience_custom'], __( 'People setting up a first home office', 'blogcraft' ) ),
				'bc_o_audience_custom'
			),
			Blogcraft_Controls::row(
				__( 'Reading level', 'blogcraft' ),
				__( 'Measured as a Flesch Reading Ease band.', 'blogcraft' ),
				Blogcraft_Controls::select( 'o_reading_level', self::reading_labels(), $bp['reading_level'] ),
				'bc_o_reading_level'
			),
			Blogcraft_Controls::row(
				__( 'Longest sentence', 'blogcraft' ),
				__( 'Measured.', 'blogcraft' ),
				Blogcraft_Controls::slider( 'o_sentence_max_words', 12, 50, 1, $bp['sentence_max_words'], __( ' words', 'blogcraft' ) ),
				'bc_o_sentence_max_words'
			),
		);

		echo implode( '', $rows );
		echo '</section>';
	}

	/**
	 * Reading level labels, without their bands.
	 *
	 * @return array
	 */
	private static function reading_labels() {
		$out = array();

		foreach ( Blogcraft_Blueprint::reading_levels() as $key => $spec ) {
			$out[ $key ] = $spec[0];
		}

		return $out;
	}

	/**
	 * Search controls for this post.
	 *
	 * @param array $bp Blueprint.
	 * @return void
	 */
	private static function tab_seo( $bp ) {
		self::tab_open( 'seo' );

		$rows = array(
			Blogcraft_Controls::row(
				__( 'Target phrase', 'blogcraft' ),
				__( 'Measured. Leave blank to let the topic speak for itself.', 'blogcraft' ),
				Blogcraft_Controls::text( 'o_primary_keyword', $bp['primary_keyword'], __( 'standing desk', 'blogcraft' ) ),
				'bc_o_primary_keyword'
			),
			Blogcraft_Controls::row(
				__( 'Also cover', 'blogcraft' ),
				__( 'One per line.', 'blogcraft' ),
				Blogcraft_Controls::area( 'o_secondary_keywords', $bp['secondary_keywords'], "adjustable desk\nsit stand desk" ),
				'bc_o_secondary_keywords'
			),
			Blogcraft_Controls::row(
				__( 'Must appear', 'blogcraft' ),
				__( 'One per line. Measured — a missing term is reported back and rewritten.', 'blogcraft' ),
				Blogcraft_Controls::area( 'o_required_terms', $bp['required_terms'], "ergonomics\nanti-fatigue mat" ),
				'bc_o_required_terms'
			),
			Blogcraft_Controls::row(
				__( 'Sources to cite', 'blogcraft' ),
				__( 'Measured.', 'blogcraft' ),
				Blogcraft_Controls::slider( 'o_external_links_target', 0, 10, 1, $bp['external_links_target'] ),
				'bc_o_external_links_target'
			),
		);

		echo implode( '', $rows );
		echo '</section>';
	}

	/**
	 * Authenticity controls for this post.
	 *
	 * @param array $bp Blueprint.
	 * @return void
	 */
	private static function tab_human( $bp ) {
		self::tab_open( 'human' );

		$rows = array(
			Blogcraft_Controls::row(
				__( 'Devices to use', 'blogcraft' ),
				'',
				Blogcraft_Controls::chips(
					'o_literary_devices',
					Blogcraft_Blueprint::literary_devices(),
					Blogcraft_Blueprint::chosen( $bp, 'literary_devices' )
				)
			),
			Blogcraft_Controls::row(
				__( 'Habits', 'blogcraft' ),
				'',
				Blogcraft_Controls::toggle( 'o_sentence_variety', $bp['sentence_variety'], __( 'Vary sentence length', 'blogcraft' ) )
				. Blogcraft_Controls::toggle( 'o_allow_contractions', $bp['allow_contractions'], __( 'Allow contractions', 'blogcraft' ) )
				. Blogcraft_Controls::toggle( 'o_allow_em_dash', $bp['allow_em_dash'], __( 'Allow em dashes', 'blogcraft' ) )
			),
			Blogcraft_Controls::row(
				__( 'Demand', 'blogcraft' ),
				'',
				Blogcraft_Controls::toggle( 'o_require_experience', $bp['require_experience'], __( 'First-hand, specific detail', 'blogcraft' ) )
				. Blogcraft_Controls::toggle( 'o_require_citations', $bp['require_citations'], __( 'A named source for claims', 'blogcraft' ) )
				. Blogcraft_Controls::toggle( 'o_require_statistics', $bp['require_statistics'], __( 'Concrete figures', 'blogcraft' ) )
			),
			Blogcraft_Controls::row(
				__( 'Never write', 'blogcraft' ),
				__( 'One per line. Measured.', 'blogcraft' ),
				Blogcraft_Controls::area( 'o_banned_phrases', $bp['banned_phrases'], "delve into\nin today's fast-paced world", 3 ),
				'bc_o_banned_phrases'
			),
			Blogcraft_Controls::row(
				__( 'Never mention', 'blogcraft' ),
				__( 'One per line. Competitors, brands, claims that must not appear at all. Measured, weighted heavily.', 'blogcraft' ),
				Blogcraft_Controls::area( 'o_negative_keywords', $bp['negative_keywords'], __( "a competitor's name", 'blogcraft' ), 3 ),
				'bc_o_negative_keywords'
			),
			Blogcraft_Controls::row(
				__( 'Steer clear of', 'blogcraft' ),
				__( 'One per line. Subjects to avoid even in passing.', 'blogcraft' ),
				Blogcraft_Controls::area( 'o_avoid_subjects', $bp['avoid_subjects'], __( 'medical advice', 'blogcraft' ), 3 ),
				'bc_o_avoid_subjects'
			),
		);

		echo implode( '', $rows );
		echo '</section>';
	}

	/**
	 * What this post will come out as.
	 *
	 * @param array $blueprint Blueprint.
	 * @return void
	 */
	private static function render_outcome( $blueprint ) {
		echo '<aside class="bc-outcome" aria-labelledby="bc-outcome-title">';
		echo '<div class="bc-outcome-head">';
		echo '<h2 id="bc-outcome-title">' . esc_html__( 'What you will get', 'blogcraft' ) . '</h2>';
		echo '<p>' . esc_html__( 'The shape of the post, not its words. Updates as you change anything.', 'blogcraft' ) . '</p>';
		echo '</div>';

		printf(
			'<div class="bc-outcome-body" id="bc-outcome-body" aria-live="polite">%s</div>',
			self::outcome_html( $blueprint )
		);

		echo '</aside>';
	}

	/**
	 * Render the predicted shape, budget and cost.
	 *
	 * @param array $blueprint Blueprint.
	 * @return string
	 */
	public static function outcome_html( $blueprint ) {
		$shape    = Blogcraft_Preview::shape( $blueprint );
		$warnings = Blogcraft_Preview::warnings( $blueprint, $shape );
		$tokens   = Blogcraft_Preview::tokens( $blueprint );

		$out = '<ol class="bc-shape">';

		foreach ( $shape as $block ) {
			$words = ( $block['words'] > 0 )
				? sprintf(
					'<span class="bc-shape-words">%s</span>',
					esc_html(
						sprintf(
							/* translators: %d: approximate word count. */
							__( '~%d words', 'blogcraft' ),
							(int) $block['words']
						)
					)
				)
				: '';

			$note = ( '' === $block['note'] )
				? ''
				: sprintf( '<span class="bc-shape-note">%s</span>', esc_html( $block['note'] ) );

			$out .= sprintf(
				'<li class="bc-shape-%1$s"><span class="bc-shape-label">%2$s</span>%3$s%4$s</li>',
				esc_attr( $block['type'] ),
				esc_html( $block['label'] ),
				$note,
				$words
			);
		}

		$out .= '</ol>';

		$out .= '<div class="bc-outcome-figures">';
		$out .= sprintf(
			'<div><span class="bc-figure">%1$s</span><span class="bc-figure-label">%2$s</span></div>',
			esc_html( number_format_i18n( (int) $blueprint['word_target'] ) ),
			esc_html__( 'Words', 'blogcraft' )
		);
		$out .= sprintf(
			'<div><span class="bc-figure">%1$s</span><span class="bc-figure-label">%2$s</span></div>',
			esc_html( self::compact( $tokens['total'] ) ),
			esc_html__( 'Tokens, roughly', 'blogcraft' )
		);
		$out .= '</div>';

		$out .= sprintf(
			'<p class="bc-hint">%s</p>',
			esc_html__( 'Token estimates are deliberately generous. Your provider bills you, not us.', 'blogcraft' )
		);

		foreach ( $warnings as $warning ) {
			$out .= sprintf( '<p class="bc-warn">%s</p>', esc_html( $warning ) );
		}

		return $out;
	}

	/**
	 * Shorten a large number for display.
	 *
	 * @param int $value Number.
	 * @return string
	 */
	private static function compact( $value ) {
		$value = (int) $value;

		if ( $value < 1000 ) {
			return (string) $value;
		}

		return number_format_i18n( $value / 1000, 1 ) . 'k';
	}

	// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped

	/**
	 * Queue a submitted topic.
	 *
	 * @return void
	 */
	public static function handle_queue() {
		// Read then verify; Blogcraft_Request performs the check PHPCS cannot follow statically.
		$nonce = isset( $_POST['_blogcraft_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_blogcraft_nonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		Blogcraft_Request::verify_or_die( self::QUEUE_ACTION, $nonce );

		// Verified above by Blogcraft_Request::verify_or_die(), which PHPCS cannot follow statically.
		$topic  = isset( $_POST['topic'] ) ? sanitize_text_field( wp_unslash( $_POST['topic'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'draft'; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( '' === $topic ) {
			self::back( false, __( 'Please enter a topic.', 'blogcraft' ) );
		}

		$instructions = isset( $_POST['instructions'] ) ? sanitize_textarea_field( wp_unslash( $_POST['instructions'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$evidence     = isset( $_POST['evidence'] ) ? sanitize_textarea_field( wp_unslash( $_POST['evidence'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$overrides    = self::overrides_from( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- each field is sanitised by type in Blogcraft_Blueprint::normalise().
		$job_id       = Blogcraft_Pipeline::enqueue_topic( $topic, $status, $instructions, $overrides, $evidence );

		if ( $job_id <= 0 ) {
			$clash = Blogcraft_Settings::get( 'duplicate_check_enabled' )
				? Blogcraft_Backlinks::find_duplicate( $topic )
				: '';

			if ( '' !== $clash ) {
				self::back(
					false,
					sprintf(
						/* translators: %s: the existing topic this one duplicates. */
						__( 'Skipped: too similar to a post you already have about "%s".', 'blogcraft' ),
						$clash
					)
				);
			}

			self::back( false, __( 'The topic could not be queued.', 'blogcraft' ) );
		}

		self::back( true, __( 'Queued. The post will be written in the background.', 'blogcraft' ) );
	}

	/**
	 * Drain the queue on demand.
	 *
	 * @return void
	 */
	public static function handle_run_now() {
		$nonce = isset( $_POST['_blogcraft_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_blogcraft_nonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		Blogcraft_Request::verify_or_die( self::RUN_ACTION, $nonce );

		Blogcraft_Queue::reclaim_stale();

		$before   = Blogcraft_Queue::count_with_errors();
		$executed = Blogcraft_Worker::run();
		$after    = Blogcraft_Queue::count_with_errors();

		$message = sprintf(
			/* translators: %d: number of pipeline steps that ran. */
			_n( '%d step ran.', '%d steps ran.', $executed, 'blogcraft' ),
			$executed
		);

		// Steps that ran and failed still count as steps, so saying only how
		// many ran would report a broken setup as a success.
		if ( $after > $before ) {
			self::back(
				false,
				$message . ' ' . __( 'Something went wrong. Blogcraft → Activity has the reason.', 'blogcraft' )
			);
		}

		self::back( true, $message );
	}

	/**
	 * Queue many topics at once.
	 *
	 * @return void
	 */
	public static function handle_bulk() {
		$nonce = isset( $_POST['_blogcraft_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_blogcraft_nonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		Blogcraft_Request::verify_or_die( self::BULK_ACTION, $nonce );

		$raw     = isset( $_POST['topics'] ) ? sanitize_textarea_field( wp_unslash( $_POST['topics'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$queued  = 0;
		$skipped = 0;

		foreach ( preg_split(
			'/[
]+/',
			$raw
		) as $line ) {
			// A pasted CSV column brings its commas with it; the first field is the topic.
			$topic = trim( (string) strtok( trim( (string) $line ), ',' ) );

			if ( '' === $topic ) {
				continue;
			}

			if ( Blogcraft_Pipeline::enqueue_topic( $topic ) > 0 ) {
				++$queued;
			} else {
				++$skipped;
			}
		}

		self::back(
			true,
			sprintf(
				/* translators: 1: number queued, 2: number skipped as duplicates. */
				__( '%1$d queued, %2$d skipped as too similar to a post you have or one already waiting.', 'blogcraft' ),
				$queued,
				$skipped
			)
		);
	}

	/**
	 * Trash generated posts from the last day.
	 *
	 * @return void
	 */
	public static function handle_rollback() {
		$nonce = isset( $_POST['_blogcraft_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_blogcraft_nonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		Blogcraft_Request::verify_or_die( self::ROLLBACK_ACTION, $nonce );

		// The generated-by-Blogcraft meta is the guard that keeps this away from
		// anything a human wrote.
		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => 100,
				'no_found_rows'  => true,
				'meta_key'       => '_blogcraft_generated', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'date_query'     => array(
					array( 'after' => '24 hours ago' ),
				),
			)
		);

		$trashed = 0;

		foreach ( $posts as $post ) {
			if ( wp_trash_post( $post->ID ) ) {
				++$trashed;
			}
		}

		self::back(
			true,
			sprintf(
				/* translators: %d: number of posts moved to the trash. */
				_n( '%d post moved to the trash.', '%d posts moved to the trash.', $trashed, 'blogcraft' ),
				$trashed
			)
		);
	}

	/**
	 * Store a one-shot notice and return to the screen.
	 *
	 * @param bool   $ok      Whether the action succeeded.
	 * @param string $message Message to show.
	 * @return void
	 */
	private static function back( $ok, $message ) {
		set_transient(
			self::NOTICE_TRANSIENT . get_current_user_id(),
			array(
				'ok'      => (bool) $ok,
				'message' => (string) $message,
			),
			60
		);

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) );
		exit;
	}
}
